/**
 * Copyright 2019 Distributed Systems Group
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package SimBlock.node.consensusAlgo;

import SimBlock.block.Block;
import SimBlock.block.ProofOfAuthorityBlock;
import SimBlock.node.Node;
import static SimBlock.settings.SimulationConfiguration.BLOCKSIZE;
import static SimBlock.settings.SimulationConfiguration.INTERVAL;
import static SimBlock.settings.SimulationConfiguration.NUM_OF_VALIDATOR;
import SimBlock.task.AuthoringTask;
import static SimBlock.simulator.Main.*;
import static SimBlock.simulator.Validator.isAllowProposeBlock;
import SimBlock.task.SampleStakingTask;

import java.math.BigInteger;

public class ProofOfAuthority extends AbstractConsensusAlgo {
	public ProofOfAuthority(Node selfNode) {
		super(selfNode);
	}
        
	@Override
	public AuthoringTask minting() {
            Node selfNode = this.getSelfNode();
            ProofOfAuthorityBlock parent = (ProofOfAuthorityBlock)selfNode.getBlock();

            if (selfNode.isValidator()){
                if (isAllowProposeBlock(parent, selfNode, 1)){

                    BigInteger difficulty = parent.getNextDifficulty();
                    int factorValidator = this.get_validator_factor(parent.getHeight(),selfNode.getQueueIndexValidator());
                    long delay = (long) (10000 * factorValidator);
                    //System.out.println(";b"+parent.getHeight()+";n"+selfNode.getQueueIndexValidator()+";f"+factorValidator+";"+delay);
                    double p =  1.0
                            / difficulty.doubleValue();//*;
                    double u = random.nextDouble();
                    long interval = ( 
                            delay +
                            (long)( Math.log(u) / Math.log(1.0-p) / selfNode.getOperationSpeed() )
                        );
                    return p <= Math.pow(2, -53) ? null : new AuthoringTask(
                            selfNode, 
                            interval, 
                            difficulty);
                }
            }
            return null;
	}
        
        public int get_validator_factor(int height_block, int index_validator){
            int index_block = (height_block % NUM_OF_VALIDATOR);
            int a;
            if (index_block <= index_validator){
                a = index_validator-index_block;
            }
            else{
                a = (NUM_OF_VALIDATOR+(index_validator-index_block));
            }                
            return a;
        }

	@Override
	public boolean isReceivedBlockValid(Block receivedBlock, Block currentBlock) {
		if (!(receivedBlock instanceof ProofOfAuthorityBlock)) return false;
		ProofOfAuthorityBlock _receivedBlock = (ProofOfAuthorityBlock)receivedBlock;
		ProofOfAuthorityBlock _currentBlock = (ProofOfAuthorityBlock)currentBlock;
		int receivedBlockHeight = receivedBlock.getHeight();
		ProofOfAuthorityBlock receivedBlockParent = receivedBlockHeight == 0 ? null : (ProofOfAuthorityBlock)receivedBlock.getBlockWithHeight(receivedBlockHeight-1);

		return (
				receivedBlockHeight == 0 ||
				_receivedBlock.getDifficulty().compareTo(receivedBlockParent.getNextDifficulty()) >= 0
			) && (
				currentBlock == null ||
				_receivedBlock.getTotalDifficulty().compareTo(_currentBlock.getTotalDifficulty()) > 0
			);
	}

	@Override
	public ProofOfAuthorityBlock genesisBlock() {
		return ProofOfAuthorityBlock.genesisBlock(this.getSelfNode());
	}
}
