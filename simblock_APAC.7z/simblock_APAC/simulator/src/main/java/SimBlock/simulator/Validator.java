/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SimBlock.simulator;

import SimBlock.block.Block;
import SimBlock.node.Node;
import static SimBlock.settings.SimulationConfiguration.NUM_OF_NODES;
import static SimBlock.settings.SimulationConfiguration.NUM_OF_VALIDATOR;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 *
 * @author ichwan
 */
public class Validator {
    //public static int[] NodeValidators;
    static List<Integer> NodeValidators;
    
    public static void GenerateValidator(){
        Random rd = new Random(); // creating Random object
        Integer[] arr = new Integer[NUM_OF_VALIDATOR];
        int min = 0;
        int max = NUM_OF_NODES;
        for (int i = 0; i < arr.length; i++) {
           arr[i] = rd.nextInt(max + 1 - min) + min;
        }
        
        Integer[] arr2 = {  124, 160,   6, 550, 194, 408, 168, 468, 282, 228, 557, 435,  59,
                            394, 242,  38, 405, 180, 255, 280, 198, 107, 239, 311, 505, 212,
                            416, 233, 406, 344,  17, 174,  57, 580, 262, 541, 547, 306,  39,
                            490, 579,  70,  71, 436, 293, 357, 334, 243, 366, 499, 312, 576,
                            410, 165, 469,  19,  31,  82, 112,  79, 412, 534, 434, 148, 122,
                            449, 136, 223, 190, 272,  14, 131, 205,  28, 142, 178, 121, 467,
                            218, 157, 347, 299, 475, 473, 290,   1, 553, 114, 267, 250, 543,
                            120, 270, 555, 484, 466, 351, 106, 482, 354     
        };
        Validator.NodeValidators = Arrays.asList(arr2);
        System.out.println(Validator.NodeValidators);
    }
    
    public static boolean CheckValidator(int nodeId){
        return Validator.NodeValidators.contains(nodeId);
    }
    
    public static int indexOfValidator(int nodeId){
        return Validator.NodeValidators.indexOf(nodeId);
    }
        
    /** When a sealer in Clique signs a block, he is not allowed to seal the next floor(N / 2) blocks
     **/
    public static boolean isAllowProposeBlock(Block perent, Node node, int flag){ 
        if (perent == null){
            return node.getQueueIndexValidator() <= Math.floor(NodeValidators.size()/ 2);
        }
        if (flag > Math.floor(NodeValidators.size()/ 2)){
            return true;
        }
        if (perent.getMinter().getNodeID() == node.getNodeID()){
           return false;
        }
        return Validator.isAllowProposeBlock(perent.getParent(), node, flag+1);
        
    }
}
