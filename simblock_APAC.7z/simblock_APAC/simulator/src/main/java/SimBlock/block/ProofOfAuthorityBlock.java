/**
 * Copyright 2019 Distributed Systems Group
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package SimBlock.block;

import java.math.BigInteger;
import SimBlock.node.Node;
import static SimBlock.settings.SimulationConfiguration.*;
import static SimBlock.simulator.Main.random;
import static SimBlock.simulator.Simulator.*;
import static SimBlock.simulator.Validator.isAllowProposeBlock;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ProofOfAuthorityBlock extends Block {
    private final BigInteger difficulty;
    private final BigInteger totalDifficulty;
    private final BigInteger nextDifficulty;
    private static BigInteger genesisNextDifficulty;
    private static ArrayList<Integer> validatorNode = new ArrayList<>();
    private boolean sealed = false;
    

    public ProofOfAuthorityBlock(ProofOfAuthorityBlock parent, Node minter, long time, BigInteger difficulty) {
        super(parent, minter, time);
        
        BigInteger numberValidation = STEP == 1 ? getNumberValidation(parent, 0) : BigInteger.valueOf(MINIMUM_VALIDATOR);
        
        BigInteger TotalOperationSpeeds = BigInteger.ZERO;
        for (Node node : getSimulatedNodes()) {
            if (node.isValidator()){
                TotalOperationSpeeds = TotalOperationSpeeds.add(BigInteger.valueOf(minter.getOperationSpeed()).multiply(numberValidation));
            }
        }
        this.difficulty = difficulty;
        this.totalDifficulty = (parent == null ? BigInteger.ZERO : parent.getTotalDifficulty()).add(difficulty);
        this.nextDifficulty = TotalOperationSpeeds.multiply(BigInteger.valueOf(getTargetInterval())).divide(BigInteger.valueOf(1000));
    }

    public BigInteger getDifficulty() {return this.difficulty;}
    public BigInteger getTotalDifficulty() {return this.totalDifficulty;}
    public BigInteger getNextDifficulty() {return this.nextDifficulty;}
    
    public void setValidator(ProofOfAuthorityBlock parent, int nodeID, int increment){
        this.validatorNode.add(nodeID);
        if (increment <= MINIMUM_VALIDATOR && parent != null){
            parent.setValidator((ProofOfAuthorityBlock) parent.getParent(), nodeID, increment+1);
        }
        if (this.validatorNode.size() >= MINIMUM_VALIDATOR){
            this.sealed = true;
        }
    }
    
    public String getValidator(){
        String listString = "";
        for (int s : this.validatorNode)
        {
            listString += s + ";";
        } 
        return listString;
    }
    
    private static BigInteger getNumberValidation(ProofOfAuthorityBlock parent, int i) {
        i++;
        if (parent == null){
            return BigInteger.valueOf(i);
        }
        if (i >= MINIMUM_VALIDATOR) return BigInteger.valueOf(i);
        
        return getNumberValidation((ProofOfAuthorityBlock)parent.getParent(), i);
    }
    
    private static BigInteger genOperationsSpeed() {
        double r = random.nextGaussian();
        return BigInteger.valueOf(Math.abs((int)(r * OPERATION_SPEED + STDDEV_OPERATION_SPEED)));
    }
        
    public static ProofOfAuthorityBlock genesisBlock(Node minter) {
        return new ProofOfAuthorityBlock(null, minter, 0, BigInteger.ZERO);
    }
}
