/**
 * Copyright 2019 Distributed Systems Group
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package SimBlock.settings;

import java.io.*;
import java.util.*;

public class SimulationConfiguration {

    public static Properties readPropertiesFile(String fileName) throws IOException {
        FileInputStream fis = null;
        Properties prop = null;
        try {
            fis = new FileInputStream(fileName);
            prop = new Properties();
            prop.load(fis);
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            fis.close();
        }
        return prop;
    }
    public static int NUM_OF_NODES = 600;//600;//800;//6000;

    public static String TABLE = "SimBlock.node.routingTable.BitcoinCoreTable";
    public static String ALGO = "SimBlock.node.consensusAlgo.SampleProofOfStake";

    // Unit: millisecond
    public static long INTERVAL = 1000 * 60 * 10;//1000*60;//1000*30*5;//1000*60*10;
    
    
    // Unit: nodes
    public static int MINIMUM_VALIDATOR = 36;
    public static int NUM_OF_VALIDATOR = 100;


    // Mining power is the number of mining (hash calculation) executed per millisecond.
    public static int AVERAGE_MINING_POWER = 400000;
    public static int STDEV_OF_MINING_POWER = 100000;

    public static int AVERAGE_COINS = 4000;
    public static int STDEV_OF_COINS = 2000;
    // min 2000 max 6000

    public static double STAKING_REWARD = 0.01;

    public static int ENDBLOCKHEIGHT = 100;
    public static String FOLDER_OUT = "output";

    // Unit: byte
    public static long BLOCKSIZE = 535000;//6110;//8000;//535000;//0.5MB

    // Unit: Kb/s need to convert byte/milisecond
    public static double OPERATION_SPEED = 6000;
    public static double STDDEV_OPERATION_SPEED = 300;

    public static int STEP = 1;
    
    public static void load_simulator_config() throws IOException {
        Properties prop = readPropertiesFile("/home/ichwan/Documents/Blockchain/simblock_APAC/simulator/src/simulation.config");
        SimulationConfiguration.INTERVAL = Long.parseLong(prop.getProperty("interval"));
        SimulationConfiguration.ALGO = prop.getProperty("algo");
        SimulationConfiguration.NUM_OF_NODES = Integer.parseInt(prop.getProperty("num_nodes"));
        SimulationConfiguration.ENDBLOCKHEIGHT = Integer.parseInt(prop.getProperty("blockheight"));
        SimulationConfiguration.BLOCKSIZE = Long.parseLong(prop.getProperty("block_size"));
//        SimulationConfiguration.MINIMUM_VALIDATOR = Integer.parseInt(prop.getProperty("minimum_validator"));
        if (prop.containsKey("minimum_validator")){
            SimulationConfiguration.MINIMUM_VALIDATOR = Integer.parseInt(prop.getProperty("minimum_validator"));
        }
        if (prop.containsKey("step")){
            SimulationConfiguration.STEP = Integer.parseInt(prop.getProperty("step"));
        }
        if (prop.containsKey("num_of_validator")){
            SimulationConfiguration.NUM_OF_VALIDATOR = Integer.parseInt(prop.getProperty("num_of_validator"));
        }
        if (prop.containsKey("operation_speed")){
            SimulationConfiguration.OPERATION_SPEED = Long.parseLong(prop.getProperty("operation_speed"));
        }
        SimulationConfiguration.FOLDER_OUT = "../" + prop.getProperty("output") + "/";
    }
}
